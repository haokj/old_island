// pages/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    onlineUrl: 'http://old_island.weixinhkj.xyz/',  //线上地址
    localUrl: 'http://old_island.com/'  //本地地址
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  gettoken:function(){
    var that = this;
    wx.login({
      success:function(res) {
        if(res.code) {
          wx.request({
            // url: 'http://old_island.com/login/login',
            url: that.data.onlineUrl + 'login/login',
            data:{
              code: res.code
            },
            success:function(data){
              
              if(data.statusCode == 200){
                console.log(data.data)
                wx.setStorageSync('token', data.data.token);
              } else {
                console.log(data);
              }
            }
          })
        }
      }
    })
  },
  checktoken:function(){
    wx.request({
      // url: 'http://old_island.com/login/check',
      url: this.data.onlineUrl + 'login/check',
      data: {
        token: wx.getStorageSync('token')
      },
      success: function (data) {

        if (data.statusCode == 200) {
          console.log(data.data)
        
        } else {
          console.log(data);
        }
      }
    })
  },
  getUserInfo:function(e){
    var userinfo = e.detail.userInfo
    wx.request({
      // url: 'http://old_island.com/save/user_info',
      url: this.data.onlineUrl + 'save/user_info',
      data:{
        token: wx.getStorageSync('token'),
        userinfo: userinfo
      },
      method: 'POST',
      success:function(res){
        console.log(e);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})
