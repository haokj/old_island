<?php
/*
* 缓存配置文件 
* @date: 2018年8月15日 下午9:38:52
* @author: hkj
*/
return [
    'expire' => '7200'    
];
