<?php
/*
 * 书籍短评模型表
* @date: 2018年8月18日 下午1:41:22
* @author: hkj
*/
namespace app\index\model;

use think\Model;

class ShortComment extends Model
{
    
}
