<?php
/*
 * 热搜关键字模型表
* @date: 2018年8月18日 下午3:53:16
* @author: hkj
*/
namespace app\index\model;

use think\Model;

class HotKeyword extends Model
{
    
}
