<?php
/*
 * 用户和短评的中间表
* @date: 2018年8月18日 下午3:06:30
* @author: hkj
*/
namespace app\index\model;

use think\Model;

class UserComment extends Model
{
    
}
