<?php
//000000007200
 exit();?>
s:50:"{"openid":"ojV8R0ag4h9LyCwNVP3-7CSm-2Ao","id":"1"}";